# Ultra Booster Max — projeto inicial Android

Este é um projeto-fonte Android Studio em Kotlin, não um APK já compilado.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Extraia esta pasta e abra `UltraBoosterMax` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de teste ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## O que esta versão faz
- Interface escura com detalhes neon verdes.
- Controles locais de sensibilidade como referência para ajuste manual no jogo.
- Atalhos para configurações de tela, bateria e informações do app.
- Botão para abrir Free Fire MAX, se instalado.

## Limitações importantes
- Os controles de sensibilidade não modificam a sensibilidade dentro do Free Fire MAX.
- O Android não permite que um app comum aumente FPS, altere taxa de atualização à força ou limpe RAM de outros apps.
- Não há acesso à memória, arquivos ou processo do jogo.
- O app não promete anti-lag nem vantagem competitiva. Use apenas configurações permitidas pelo jogo e pelo Android.
