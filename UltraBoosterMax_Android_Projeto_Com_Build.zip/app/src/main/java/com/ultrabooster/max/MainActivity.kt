package com.ultrabooster.max

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 11, 10)
    private val panel = Color.rgb(17, 25, 22)
    private val neon = Color.rgb(57, 255, 136)
    private val muted = Color.rgb(160, 180, 169)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 26, 22, 30)
            setBackgroundColor(bg)
        }
        scroll.addView(page)

        page.addView(label("ULTRA BOOSTER", 27f, neon, true))
        page.addView(label("MAX  •  FREE FIRE MAX EDITION", 12f, muted, true))
        page.addView(space(18))

        val status = card()
        status.addView(label("PAINEL DE DESEMPENHO", 14f, neon, true))
        status.addView(label("Prepare seu Android antes de entrar no jogo.", 13f, Color.WHITE))
        status.addView(label("Este app não altera arquivos, mira ou memória do Free Fire.", 11f, muted))
        page.addView(status)

        page.addView(section("SENSIBILIDADE • PERFIL DE REFERÊNCIA"))
        page.addView(label("Ajuste os valores como referência para configurar manualmente no jogo.", 12f, muted))
        sensitivityControl(page, "Geral", 95)
        sensitivityControl(page, "Ponto vermelho", 90)
        sensitivityControl(page, "Mira 2x", 85)
        sensitivityControl(page, "Mira 4x", 80)
        sensitivityControl(page, "Mira AWM", 50)
        sensitivityControl(page, "Olhadinha", 75)

        page.addView(section("ATALHOS DO ANDROID"))
        addAction(page, "ABRIR CONFIGURAÇÕES DE TELA", "Ajuste brilho, taxa de atualização e tempo limite nas opções do aparelho.") {
            openSettings(Settings.ACTION_DISPLAY_SETTINGS)
        }
        addAction(page, "ABRIR CONFIGURAÇÕES DE BATERIA", "Confira economia de energia e uso da bateria.") {
            openSettings(Intent.ACTION_POWER_USAGE_SUMMARY)
        }
        addAction(page, "ABRIR CONFIGURAÇÕES DO APP", "Veja permissões e opções disponíveis para este aplicativo.") {
            openSettings(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        }

        page.addView(section("INICIAR FREE FIRE MAX"))
        val play = button("ABRIR FREE FIRE MAX")
        play.setOnClickListener {
            val launch = packageManager.getLaunchIntentForPackage("com.dts.freefiremax")
            if (launch != null) startActivity(launch)
            else Toast.makeText(this, "Free Fire MAX não encontrado. Instale o jogo primeiro.", Toast.LENGTH_LONG).show()
        }
        page.addView(play)

        page.addView(space(14))
        page.addView(label("DICA: feche apps que não está usando e evite jogar enquanto o celular estiver superaquecido.", 11f, muted))
        page.addView(space(8))
        page.addView(label("ULTRA BOOSTER MAX • VERSÃO INICIAL 1.0", 10f, muted, true))
        setContentView(scroll)
    }

    private fun sensitivityControl(parent: LinearLayout, name: String, initial: Int) {
        val box = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(label(name, 14f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        val value = label("$initial", 14f, neon, true)
        row.addView(value)
        box.addView(row)
        val seek = SeekBar(this).apply {
            max = 100
            progress = initial
            progressTintList = android.content.res.ColorStateList.valueOf(neon)
            thumbTintList = android.content.res.ColorStateList.valueOf(neon)
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { value.text = "$p" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(seek)
        parent.addView(box)
    }

    private fun addAction(parent: LinearLayout, title: String, desc: String, action: () -> Unit) {
        val box = card()
        box.addView(label(title, 14f, neon, true))
        box.addView(label(desc, 12f, muted))
        val b = button("ABRIR")
        b.setOnClickListener { action() }
        box.addView(b)
        parent.addView(box)
    }

    private fun openSettings(action: String, data: Uri? = null) {
        try {
            val intent = Intent(action)
            if (data != null) intent.data = data
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Essa opção não está disponível neste Android.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun section(text: String): TextView = label(text, 15f, neon, true).apply {
        setPadding(2, 22, 2, 9)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(16, 14, 16, 14)
        setBackgroundColor(panel)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = 10
        layoutParams = lp
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 3, 0, 3)
        }

    private fun button(text: String): Button = Button(this).apply {
        this.text = text
        setTextColor(Color.BLACK)
        textSize = 12f
        setBackgroundColor(neon)
        isAllCaps = false
    }

    private fun space(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, height)
    }
}
